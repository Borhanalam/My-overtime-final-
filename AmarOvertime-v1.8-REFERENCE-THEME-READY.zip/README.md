# আমার ওভারটাইম — v1.8 Reference Theme

This build keeps the existing Android/WebView functionality and applies the supplied
electrician icon and cream/teal/gold visual direction across the Home, Duty Planner,
Records and Settings screens.

Build workflow:
.github/workflows/android.yml
