# আমার ওভার টাইম — Android App

**App name:** আমার ওভার টাইম  
**Developer:** BORHAN  
**Application ID:** `com.borhan.amarot`  
**Version:** 1.2 (versionCode 3)

## Included
- Supplied app icon and BORHAN branding
- Bengali mobile-first dashboard
- Monthly salary, OT, attendance bonus and cumulative late calculation
- Day / Night / Holiday / Leave / Absence duty records
- Multiple Worker profiles
- Worker-specific salary settings and duty history
- Search, edit and delete records
- CSV export to Android Downloads
- Full JSON Backup / Restore through Android file picker
- Offline-first local storage
- Android 12+ splash screen configuration
- targetSdk 36 / compileSdk 36

## Open in Android Studio
1. Open the project folder in Android Studio.
2. Let Gradle sync finish.
3. Connect an Android phone or start an emulator.
4. Run the `app` configuration.

## Generate Play Store AAB
Use **Build → Generate Signed Bundle / APK → Android App Bundle**.
Create your own upload/release keystore and keep it private. `keystore.properties.example` is provided as a template.

## Privacy policy
`PRIVACY_POLICY.md` contains the current offline-data privacy policy text. For Play Console, publish the policy at a public HTTPS URL (for example, from your own GitHub Pages site) and enter that URL in Play Console.

## Important
This project does not contain a signing key. A Play Store release must be signed with a keystore controlled by the developer.



## Updated attendance rules

- Monthly cumulative late is calculated across all Day Duty records in the selected month.
- If total monthly late is **15 minutes or less**, the ৳625 attendance bonus is added.
- If total monthly late is **more than 15 minutes**, the ৳625 attendance bonus is not added.
- Holiday Duty, Night Duty, Leave and Absence do not add late minutes.
- Leave gives 8 regular attendance hours, but the monthly attendance bonus is not granted.
- Absence gives 0 attendance hours, deducts one daily salary amount, and the monthly attendance bonus is not granted.
- Every 3 calendar records/days with **15 minutes or more late** causes one additional daily-salary deduction.
- Day Duty: 08:00–17:00, with 13:00–14:00 lunch; time after 17:00 is OT.
- Night Duty: 20:00–04:00; time beyond the regular 8 hours is OT.
- Holiday Duty: all worked time is OT except the 13:00–14:00 lunch overlap; no late is counted.
- No separate Night Bill allowance is included in this version.


## Version 1.3 calculation rules

- Day Duty late is calculated after 08:00.
- Night Duty late is calculated after 20:00.
- Holiday Duty has no late.
- Leave counts as 8 hours general attendance and does not cancel the attendance bonus.
- Absence counts as 0 attendance and cancels the monthly attendance bonus.
- Monthly total late <= 15 minutes: attendance bonus is added; >15 minutes: bonus is not added.
- Every 3 days with late >=15 minutes causes one day salary deduction.
- Night Duty crossing midnight receives the configured Night Bill.
- Holiday Duty worked hours are OT after subtracting the 13:00-14:00 lunch break.
