const KEY = "amarOvertime_v2";
let data = JSON.parse(localStorage.getItem(KEY) || "null");
if (!data) data = {activeWorkerId:1, workers:[{id:1,name:"আমার হিসাব",settings:{}}], records:{1:[]}};
if (!Array.isArray(data.workers) || !data.workers.length) { data.workers=[{id:1,name:"আমার হিসাব",settings:{}}]; data.activeWorkerId=1; }
data.records = data.records || {};
const $ = id => document.getElementById(id);
const activeWorker = () => data.workers.find(w => w.id === data.activeWorkerId) || data.workers[0];
function workerRecords(){const w=activeWorker(); return data.records[w.id]||(data.records[w.id]=[])}
function save(){localStorage.setItem(KEY,JSON.stringify(data)); renderAll()}
function todayLocal(){const d=new Date(),off=d.getTimezoneOffset();return new Date(d.getTime()-off*60000).toISOString().slice(0,10)}
function money(n){return "৳"+(Number(n)||0).toFixed(2)}
function fmtHours(n){return (Number(n)||0).toFixed(2)}
function settings(){
  const w=activeWorker(),s=w.settings||{};
  return {
    salary:Number($('salary').value)||0,
    salaryDays:Number($('salaryDays').value)||26,
    regularHours:Number($('regularHours').value)||8,
    otMultiplier:2,
    attendanceBonus:Number($('attendanceBonus').value)||625,
    lateLimit:Number($('lateLimit').value)||15,
    nightBill:Number($('nightBill').value)||100
  };
}
function loadSettings(){
  const s=activeWorker().settings||{};
  for(const k of ['salary','salaryDays','regularHours','otMultiplier','attendanceBonus','lateLimit','nightBill']) if(s[k]!==undefined&&$(k)) $(k).value=s[k];
  if(!$('salary').value)$('salary').value='15000';
  if($('salaryDays')&&!$('salaryDays').value)$('salaryDays').value='26';
  if($('regularHours')&&!$('regularHours').value)$('regularHours').value='8';
  if($('attendanceBonus')&&!$('attendanceBonus').value)$('attendanceBonus').value='625';
  if($('lateLimit'))$('lateLimit').value=15;
  if($('nightBill')&&!$('nightBill').value)$('nightBill').value='100';
}
function persistSettings(){activeWorker().settings=settings();localStorage.setItem(KEY,JSON.stringify(data));renderAll()}
function minutes(t){if(!t)return 0;const [h,m]=t.split(':').map(Number);return h*60+m}
function duration(a,b){let x=minutes(a),y=minutes(b);if(y<=x)y+=1440;return y-x}
function lunchOverlapDay(inTime,outTime){let start=minutes(inTime),end=minutes(outTime);if(end<=start)end+=1440;let ls=780,le=840;if(ls<start)ls+=1440;if(le<=start)le+=1440;return Math.max(0,Math.min(end,le)-Math.max(start,ls))}
function dutyTypeOf(r){return r.dutyType || (r.status==='holiday'?'holiday':r.status==='leave'?'leave':(r.status==='absent'?'absence':'day'))}
function lateForRecord(r){
  const type=dutyTypeOf(r);
  if(!r.inTime) return 0;
  if(type==='day') return Math.max(0,minutes(r.inTime)-480);   // Day starts 08:00
  if(type==='night') return Math.max(0,minutes(r.inTime)-1200); // Night starts 20:00
  return 0; // Holiday / Leave / Absence: no late
}
function calculate(r){
  const s=settings();
  const type=dutyTypeOf(r);
  if(type==='absence') return {regular:0,ot:0,late:0,night:0,total:0};
  if(type==='leave') return {regular:s.regularHours,ot:0,late:0,night:0,total:s.regularHours};
  if(!r.inTime || !r.outTime) return {regular:0,ot:0,late:0,night:0,total:0};

  const totalMinutes=duration(r.inTime,r.outTime), totalHours=totalMinutes/60;
  const inM=minutes(r.inTime), outM=minutes(r.outTime);
  const crossesMidnight=outM<=inM;
  const nightBill=crossesMidnight ? s.nightBill : 0;

  if(type==='holiday'){
    const lunch=lunchOverlapDay(r.inTime,r.outTime);
    const ot=Math.max(0,totalMinutes-lunch)/60;
    return {regular:0,ot,late:0,night:nightBill,total:totalHours};
  }

  if(type==='night'){
    const regular=Math.min(s.regularHours,totalHours);
    const ot=Math.max(0,totalHours-s.regularHours);
    const late=lateForRecord(r);
    return {regular,ot,late,night:nightBill,total:totalHours};
  }

  // Day Duty: 08:00 start, 17:00 general-duty end; 13:00-14:00 lunch is part of general duty.
  const late=lateForRecord(r);
  let end=outM;
  if(end<=inM) end+=1440;
  let cutoff=1020; // 17:00
  if(cutoff<inM) cutoff+=1440;
  const ot=Math.max(0,end-cutoff)/60;
  const regular=Math.min(s.regularHours,Math.max(0,totalHours-ot));
  return {regular,ot,late,night:nightBill,total:totalHours};
}
function monthStats(ym){
  const s=settings();
  ym = ym || `${calendarCursor.getFullYear()}-${String(calendarCursor.getMonth()+1).padStart(2,'0')}`;
  const rs=workerRecords().filter(r=>String(r.date||'').startsWith(ym));
  let present=0,absent=0,leave=0,holiday=0,regular=0,ot=0,totalLate=0,longLateDays=0,night=0;
  rs.forEach(r=>{
    const type=dutyTypeOf(r), c=calculate(r);
    if(type==='absence') absent++;
    else if(type==='leave') leave++;
    else if(type==='holiday') holiday++;
    else present++;
    regular+=c.regular; ot+=c.ot; totalLate+=c.late; night+=c.night;
    if(c.late>=15) longLateDays++;
  });
  const hourly=(s.salary*0.5605)/(s.salaryDays*s.regularHours);
  const otRate=hourly*s.otMultiplier;
  const otPay=ot*otRate;
  // Leave does NOT cancel the attendance bonus. Absence does.
  const bonusEligible = totalLate<=s.lateLimit && absent===0;
  const bonus=bonusEligible?s.attendanceBonus:0;
  // Every 3 days with 15 minutes or more late = one day's salary deduction.
  const latePenaltyDays=Math.floor(longLateDays/3);
  const dailySalary=s.salary/s.salaryDays;
  const salaryDeduction=latePenaltyDays*dailySalary;
  const total=s.salary-salaryDeduction+otPay+bonus+night;
  return {rs,present,absent,leave,holiday,regular,ot,totalLate,longLateDays,late:totalLate,night,hourly,otRate,otPay,bonus,bonusEligible,latePenaltyDays,salaryDeduction,dailySalary,total};
}
function stat(t,v,cls='',primary=false){
  const icons={
    'এই মাসের মোট বেতন':'৳','Present':'✓','Leave':'▣','Absence':'!','Regular Hours':'◷','OT Hours':'⚡','OT Wage':'৳','মোট Late':'◴','১৫+ মিনিটের Late দিন':'◌','Late Penalty':'▤','Night Bill':'☾','Attendance Bonus':'★'
  };
  const icon=icons[t]||'•';
  return `<div class="stat ${primary?'primary':''}"><span class="stat-icon">${icon}</span><div class="stat-copy"><small>${t}</small><strong class="${cls}">${v}</strong></div></div>`
}
function typeLabel(t){return t==='night'?'Night Duty':t==='holiday'?'Holiday Duty':t==='leave'?'Leave':t==='absence'?'Absence':'Day Duty'}
function renderDashboard(){
  const selectedYM=`${calendarCursor.getFullYear()}-${String(calendarCursor.getMonth()+1).padStart(2,'0')}`;
  const m=monthStats(selectedYM),s=settings(),w=activeWorker();
  $('activeWorkerName').textContent=w.name;
  $('activeWorkerMeta').textContent=`${selectedYM} • মাসিক হিসাব`; if($('settingsWorkerName')) $('settingsWorkerName').textContent=w.name;
  $('dashboard').innerHTML=[
    stat('এই মাসের মোট বেতন',money(m.total),'',true),stat('Present',m.present),stat('Leave',m.leave),stat('Absence',m.absent),
    stat('Regular Hours',fmtHours(m.regular)),stat('OT Hours',fmtHours(m.ot)),stat('OT Wage',money(m.otPay)),
    stat('মোট Late',m.totalLate+' min',m.totalLate>15?'bad':''),stat('১৫+ মিনিটের Late দিন',m.longLateDays),
    stat('Late Penalty',m.latePenaltyDays+' দিন',m.latePenaltyDays?'bad':''),stat('Night Bill',money(m.night)),
    stat('Attendance Bonus',money(m.bonus),m.bonus?'ok':'bad')
  ].join('');
}
function renderToday(){
  const r=workerRecords().find(x=>x.date===todayLocal());
  if(!r){$('todayCard').innerHTML='<div class="empty">আজকের কোনো ডিউটি সেভ করা হয়নি।</div>';return}
  const c=calculate(r);
  $('todayCard').innerHTML=`<div class="today-row"><div><strong>${typeLabel(dutyTypeOf(r))}</strong><br><span class="badge ${dutyTypeOf(r)}">${dutyTypeOf(r)}</span></div><div><b>OT ${fmtHours(c.ot)} h</b><br><small>${r.inTime||'-'} → ${r.outTime||'-'}${c.late?' • Late '+c.late+' min':''}${c.night?' • Night Bill '+money(c.night):''}</small></div></div>`;
}
function renderRecent(){
  const rs=workerRecords().slice().sort((a,b)=>b.date.localeCompare(a.date)).slice(0,5);
  $('recentRecords').innerHTML=rs.length?rs.map(r=>{const c=calculate(r);return `<div class="record-row" style="padding:10px 0;border-bottom:1px solid #e2e8f0"><div><b>${r.date}</b><br><small>${typeLabel(dutyTypeOf(r))}</small></div><div><b>OT ${fmtHours(c.ot)}h</b><br><small>${c.late?'Late '+c.late+' min':'No Late'}${c.night?' • Night '+money(c.night):''}</small></div></div>`}).join(''):'<div class="empty">এখনও কোনো রেকর্ড নেই।</div>';
}
function renderRecords(){
  const q=($('recordSearch').value||'').toLowerCase();
  let rs=workerRecords().slice().sort((a,b)=>b.date.localeCompare(a.date));
  if(q)rs=rs.filter(r=>`${r.date} ${dutyTypeOf(r)} ${r.notes||''}`.toLowerCase().includes(q));
  $('recordCount').textContent=`${rs.length}টি রেকর্ড`;
  $('records').innerHTML=rs.map(r=>{const c=calculate(r);return `<tr><td>${r.date}</td><td>${typeLabel(dutyTypeOf(r))}</td><td>${dutyTypeOf(r)}</td><td>${r.inTime||'-'}</td><td>${r.outTime||'-'}</td><td>${fmtHours(c.regular)}</td><td>${fmtHours(c.ot)}</td><td>${c.late}</td><td>${money(c.night)}</td><td><button class="mini secondary" onclick="editRecord(${r.id})">Edit</button> <button class="mini danger" onclick="deleteRecord(${r.id})">Delete</button></td></tr>`}).join('')||'<tr><td colspan="10" class="empty">কোনো রেকর্ড পাওয়া যায়নি।</td></tr>';
}
function renderWorkers(){
  const list=$('workerList');
  list.innerHTML=data.workers.map(w=>`<div class="worker-item"><div><b>${escapeHtml(w.name)}</b><div class="meta">${w.id===data.activeWorkerId?'✓ Active Worker':''}</div></div><div class="worker-actions"><button onclick="selectWorker(${w.id})">${w.id===data.activeWorkerId?'Active':'Select'}</button>${data.workers.length>1?`<button class="danger" onclick="deleteWorker(${w.id})">Delete</button>`:''}</div></div>`).join('');
}
function escapeHtml(s){return String(s).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
let calendarCursor=new Date();
function renderCalendar(){
  const root=$('monthCalendar'); if(!root) return;
  const y=calendarCursor.getFullYear(), m=calendarCursor.getMonth();
  const names=['জানুয়ারি','ফেব্রুয়ারি','মার্চ','এপ্রিল','মে','জুন','জুলাই','আগস্ট','সেপ্টেম্বর','অক্টোবর','নভেম্বর','ডিসেম্বর'];
  $('calendarTitle').textContent=`${names[m]} ${y}`;
  const first=new Date(y,m,1).getDay(), days=new Date(y,m+1,0).getDate();
  const today=todayLocal(); let html='';
  for(let i=0;i<first;i++) html+='<span class="cal-day muted"></span>';
  for(let d=1;d<=days;d++){
    const ds=`${y}-${String(m+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
    const rec=workerRecords().find(r=>r.date===ds);
    const type=rec?dutyTypeOf(rec):'';
    html+=`<button class="cal-day ${ds===today?'today':''} ${type}" data-date="${ds}">${d}${rec?`<i></i>`:''}</button>`;
  }
  root.innerHTML=html;
  root.querySelectorAll('.cal-day[data-date]').forEach(b=>b.onclick=()=>{ const [yy,mm,dd]=b.dataset.date.split('-').map(Number); calendarCursor=new Date(yy,mm-1,dd); $('date').value=b.dataset.date; renderDashboard(); renderCalendar(); showPage('dutyPage'); });
}
function renderAll(){loadSettings();renderDashboard();renderToday();renderRecent();renderRecords();renderWorkers();renderCalendar()}
function showPage(id){document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active',p.id===id));document.querySelectorAll('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.page===id));window.scrollTo(0,0)}
function toast(msg){const t=$('toast');t.textContent=msg;t.classList.add('show');clearTimeout(window._toast);window._toast=setTimeout(()=>t.classList.remove('show'),2200)}
function setDefaults(){if($('date'))$('date').value=todayLocal();if($('dutyType'))$('dutyType').value='day';if($('inTime'))$('inTime').value='08:00';if($('outTime'))$('outTime').value='17:00'}
function applyTypeDefaults(){const t=$('dutyType').value;if(t==='day'){$('inTime').value='08:00';$('outTime').value='17:00'}else if(t==='night'){$('inTime').value='20:00';$('outTime').value='04:00'}else if(t==='holiday'){$('inTime').value='08:00';$('outTime').value='17:00'}else{$('inTime').value='';$('outTime').value=''}}
$('dutyType').addEventListener('change',applyTypeDefaults);
$('dutyForm').addEventListener('submit',e=>{
  e.preventDefault();
  const type=$('dutyType').value;
  const r={id:Date.now(),date:$('date').value,dutyType:type,status:type,inTime:$('inTime').value,outTime:$('outTime').value,notes:$('notes').value};
  if(['leave','absence'].includes(type)){r.inTime='';r.outTime=''}
  const rs=workerRecords(),i=rs.findIndex(x=>x.date===r.date);
  if(i>=0)rs[i]=r;else rs.push(r);
  rs.sort((a,b)=>a.date.localeCompare(b.date));
  save();setDefaults();$('notes').value='';toast('ডিউটি সেভ হয়েছে');showPage('homePage');
});
$('clearBtn').onclick=()=>{$('dutyForm').reset();setDefaults()};
$('recordSearch').addEventListener('input',renderRecords);
['salary','salaryDays','regularHours','otMultiplier','attendanceBonus','lateLimit','nightBill'].forEach(id=>$(id).addEventListener('input',persistSettings));
$('addWorkerBtn').onclick=()=>{const name=$('workerName').value.trim();if(!name)return toast('Worker-এর নাম দিন');const id=Date.now();data.workers.push({id,name,settings:{}});data.records[id]=[];data.activeWorkerId=id;$('workerName').value='';save();toast('Worker যোগ হয়েছে')};
window.selectWorker=id=>{data.activeWorkerId=id;save();toast('Active Worker পরিবর্তন হয়েছে');showPage('homePage')};
window.deleteWorker=id=>{if(data.workers.length<=1)return toast('কমপক্ষে একজন Worker থাকতে হবে');if(!confirm('এই Worker এবং তার সব record মুছবেন?'))return;data.workers=data.workers.filter(w=>w.id!==id);delete data.records[id];data.activeWorkerId=data.workers[0].id;save()};
window.editRecord=id=>{const r=workerRecords().find(x=>x.id===id);if(!r)return;$('date').value=r.date;$('dutyType').value=dutyTypeOf(r);$('inTime').value=r.inTime||'';$('outTime').value=r.outTime||'';$('notes').value=r.notes||'';data.records[activeWorker().id]=workerRecords().filter(x=>x.id!==id);localStorage.setItem(KEY,JSON.stringify(data));showPage('dutyPage');window.scrollTo(0,0)};
window.deleteRecord=id=>{if(confirm('এই record মুছবেন?')){data.records[activeWorker().id]=workerRecords().filter(x=>x.id!==id);save();toast('Record মুছে ফেলা হয়েছে')}};
$('clearAllBtn').onclick=()=>{if(confirm('এই Worker-এর সব record মুছবেন?')){data.records[activeWorker().id]=[];save();toast('সব record মুছে গেছে')}};
function downloadNative(content,fileName,mime){const bytes=new TextEncoder().encode(content);let bin='';bytes.forEach(b=>bin+=String.fromCharCode(b));const base64=btoa(bin);if(window.AndroidApp&&AndroidApp.saveFile)AndroidApp.saveFile(base64,fileName,mime);else{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([content],{type:mime}));a.download=fileName;a.click()}}
$('exportBtn').onclick=()=>{const rows=[['Date','Duty Type','In','Out','Regular Hours','OT Hours','Late Minutes','Night Bill','Notes']];workerRecords().forEach(r=>{const c=calculate(r);rows.push([r.date,dutyTypeOf(r),r.inTime||'',r.outTime||'',c.regular,c.ot,c.late,c.night,r.notes||''])});const csv='\ufeff'+rows.map(row=>row.map(v=>`"${String(v).replaceAll('"','""')}"`).join(',')).join('\n');downloadNative(csv,'amar-overtime-records.csv','text/csv;charset=utf-8');toast('CSV export করা হয়েছে')};
$('backupBtn').onclick=()=>downloadNative(JSON.stringify(data,null,2),'amar-overtime-backup.json','application/json');
$('restoreBtn').onclick=()=>{if(window.AndroidApp&&AndroidApp.openBackup)AndroidApp.openBackup();else toast('Android app থেকেই Restore করুন')};
window.importBackup=json=>{try{const incoming=JSON.parse(json);if(!incoming.workers||!incoming.records)throw Error();data=incoming;localStorage.setItem(KEY,JSON.stringify(data));renderAll();toast('Backup সফলভাবে Restore হয়েছে')}catch(e){toast('Backup ফাইলটি সঠিক নয়')}};
$('quickWorkerBtn').onclick=()=>showPage('settingsPage');
if($('prevMonthBtn'))$('prevMonthBtn').onclick=()=>{calendarCursor.setMonth(calendarCursor.getMonth()-1);renderCalendar();renderDashboard()};
if($('nextMonthBtn'))$('nextMonthBtn').onclick=()=>{calendarCursor.setMonth(calendarCursor.getMonth()+1);renderCalendar();renderDashboard()};
document.querySelectorAll('[data-page]').forEach(b=>b.addEventListener('click',()=>showPage(b.dataset.page)));
function tick(){$('clock').textContent=new Date().toLocaleString('bn-BD',{dateStyle:'medium',timeStyle:'short'})}
setInterval(tick,1000);tick();setDefaults();renderAll();
